import os
import pathlib

import requests
from bson import ObjectId
from flask import Flask, session, abort, redirect, request, render_template
from google.oauth2 import id_token
from google_auth_oauthlib.flow import Flow
from pip._vendor import cachecontrol
import google.auth.transport.requests
import pymongo as db

app = Flask("Vulkan")
app.secret_key = "-EGVzOiluQHyOi4Wco2j2PsU"

os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"

GOOGLE_CLIENT_ID = "439825728270-sakkkvplrmp6ahbhkqorjgh618cbsaqd.apps.googleusercontent.com"
client_secrets_file = os.path.join(
    pathlib.Path(__file__).parent, "client_secret.json")

flow = Flow.from_client_secrets_file(
    client_secrets_file=client_secrets_file,
    scopes=["https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email",
            "openid"],
    redirect_uri="http://127.0.0.1:5000/callauth"
)
myclient = db.MongoClient("mongodb://localhost:27017/")
mydb = myclient["local"]
gpulist = mydb["gpudb"]


def login_is_required(function):
    def wrapper(*args, **kwargs):
        if "google_id" not in session:
            return abort(401)  # Authorization required
        else:
            return function()

    return wrapper


@app.route("/login")
def login():
    authorization_url, state = flow.authorization_url()
    session["state"] = state
    return redirect(authorization_url)


@app.route("/callauth")
def callauth():
    flow.fetch_token(authorization_response=request.url)

    if not session["state"] == request.args["state"]:
        abort(500)  # State does not match!

    credentials = flow.credentials
    request_session = requests.session()
    cached_session = cachecontrol.CacheControl(request_session)
    token_request = google.auth.transport.requests.Request(
        session=cached_session)

    id_info = id_token.verify_oauth2_token(
        id_token=credentials._id_token,
        request=token_request,
        audience=GOOGLE_CLIENT_ID
    )

    session["google_id"] = id_info.get("sub")
    session["name"] = id_info.get("name")
    return redirect("/list")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


@app.route("/edit/<id>", methods=['POST', 'GET'])
def editpage(id):
    return render_template('Edit.html', focalgpu=gpulist.find({'_id': ObjectId(id)}).next())


@app.route("/update", methods=['POST', 'GET'])
def updateInfo():
    if request.method == 'POST':
        oid = request.form.get('oid')
        # print(oid)
        udevice = request.form.get('device')
        # print(udevice)
        udriver = request.form.get('driver')
        # print(udriver)
        uapi = request.form.get('api')
        # print(uapi)
        uvendor = request.form.get('vendor')
        # print(uvendor)
        utype = request.form.get('type')
        # print(utype)
        uos = request.form.get('os')
        # print(uos)
        uplatform = request.form.get('platform')
        # print(uplatform)
        ugs = request.form.get('gs')
        # print(ugs)
        uts = request.form.get('ts')
        # print(uts)
        usi16 = request.form.get('si16')
        # print(usi16)
        usb = request.form.get('sb')
        # print(usb)
        utcetc2 = request.form.get('tcetc2')
        # print(utcetc2)
        uvpsaa = request.form.get('vpsaa')
        # print(uvpsaa)
        if ugs == 'on':
            ugs = 1
        else:
            ugs = 0
        
        if uts == 'on':
            uts = 1
        else:
            uts = 0

        if usi16 == 'on':
            usi16 = 1
        else:
            usi16 = 0

        if usb == 'on':
            usb = 1
        else:
            usb = 0

        if utcetc2 == 'on':
            utcetc2 = 1
        else:
            utcetc2 = 0

        if uvpsaa == 'on':
            uvpsaa = 1
        else:
            uvpsaa = 0
        gpulist.update_one({"_id": ObjectId(oid)}, {"$set": {'Device': udevice,
                                                             'Driver': udriver,
                                                             'Api': uapi,
                                                             'Vendor': uvendor,
                                                             'Type': utype,
                                                             'OS': uos,
                                                             'platform': uplatform,
                                                             'feature': {
                                                                 'GeometryShader': ugs,
                                                                 'TesselationShader': uts,
                                                                 'ShaderInt16': usi16,
                                                                 'SparseBinding': usb,
                                                                 'TextureCompressionETC2': utcetc2,
                                                                 'VertexPipelineStoreandAtomic': uvpsaa
                                                             }}})
    return redirect(f'./edit/{oid}')


@app.route("/")
def index():
    return render_template('Welcome.html')


@app.route("/list")
@login_is_required
def protected_area():
    # IMPLEMENT MONGO DB HERE

    list_of_gpu = gpulist.find()
    return render_template('GpuList.html', list_of_gpu=list_of_gpu, k=list_of_gpu)


if __name__ == "__main__":
    app.run(debug=True)
